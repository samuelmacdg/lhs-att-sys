// JOHN GLAY C. BUNAO
// 12-RITCHIE

// ScrollReveal Animation
const sr = ScrollReveal({
    origin: 'top',
    distance: '60px',
    duration: 2500,
    delay: 400,
    // reset: true
})

sr.reveal('.home-img, .contact-img', { origin: 'right' })
sr.reveal('.home-text, .contact-text', { origin: 'left' })
sr.reveal('.team-intro, .profile')
sr.reveal('.team-grid', { interval: 100, delay: 50 })
sr.reveal('.footer-items, .footer-text', { interval: 100 })