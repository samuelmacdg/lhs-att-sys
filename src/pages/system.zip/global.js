/*jshint esversion: 11 */

const signUpOnLoad = () => {
    const btnPressed = document.createElement('style');
    btnPressed.type = 'text/css';
    btnPressed.innerHTML = '.btn-pressed {background-color: #953b39; color: white;}';
    document.getElementsByTagName('head')[0].appendChild(btnPressed);


    const teacherStudentOnClick = (ev) => {
        const el = ev.target;
        const isTeacher = el.classList.contains("teacher-btn");
        const isActive = el.classList.contains("btn-pressed");

        const tEl = document.getElementsByClassName("teacher-btn")[0];
        const sEl = document.getElementsByClassName("student-btn")[0];
        const inp = document.getElementById("isteacher");

        const selectTeacher = () => {
            sEl.classList.remove("btn-pressed");
            tEl.classList.add("btn-pressed");
            inp.value = true;
        };
        const selectStudent = () => {
            tEl.classList.remove("btn-pressed");
            sEl.classList.add("btn-pressed");
            inp.value = false;
        };

        if (isTeacher) {
            if (isActive)
                selectStudent();
            else
                selectTeacher();
        }
        else {
            if (isActive)
                selectTeacher();
            else
                selectStudent();
        }
    };
    const signUpForm = document.getElementsByClassName("sign-form")[0];
    const isTeacherInput = document.createElement('input');
    isTeacherInput.type = "checkbox";
    isTeacherInput.name = "isteacher";
    isTeacherInput.value = false;
    isTeacherInput.id = "isteacher";
    isTeacherInput.style.height = "0px";
    isTeacherInput.style.padding = "0px";
    isTeacherInput.style.visibility = "collapse";
    signUpForm.appendChild(isTeacherInput);
    document.getElementsByClassName('teacher-btn')[0].addEventListener('click', teacherStudentOnClick);
    document.getElementsByClassName('student-btn')[0].addEventListener('click', teacherStudentOnClick);
    document.getElementsByClassName('student-btn')[0].classList.add("btn-pressed");
};

const profileOnLoad = () => {
    $.getJSON('./profile-json', data => {
        $("input[name='username']").val(data.username);
        $("input[name='email']").val(data.username);
        $("input[name='firstname']").val(data.firstname);
        $("input[name='lastname']").val(data.lastname);

        if(data.type == 1){
            $(".teacher-student")[0].children[0].classList.add("active");
            $(".teacher-student")[0].children[1].classList.remove("active");
        }
    }).catch((error) => { alert(JSON.stringify(error)); });
};